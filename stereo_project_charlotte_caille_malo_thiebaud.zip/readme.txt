This project was made by Charlotte Caillé and Malo Thiébaud.
The code is accessible at https://github.com/Astri2/astri2.github.io